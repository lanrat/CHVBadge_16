﻿/******************************************************************************
 * Copyright 2016 Specialized Solutions LLC
 *
 * Title to the Materials (contents of this file) remain with Specialized
 * Solutions LLC.  The Materials are copyrighted and are protected by United
 * States copyright laws.  Copyright notices cannot be removed from the
 * Materials.
 *
 * See the file titled "Specialized Solutions LLC License Agreement.txt"
 * that has been distributed with this file for further licensing details.
 *
 *****************************************************************************/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;

namespace QCMUsb
{
    public class QCMDevice
    {
        public delegate void evDebugDataReceivedHandler(object sender, String received_data);
        public event evDebugDataReceivedHandler evDebugDataReceived;

        public delegate void evQCMDisconnectedHandler(object sender);
        public event evQCMDisconnectedHandler evQCMDisconnected;

        public delegate void evQCMConnectedHandler(object sender, bool in_bootloader, byte[] serial_num, UInt32 app_version, UInt32 script_ver, byte[] mfg_info, String customer_id);
        public event evQCMConnectedHandler evQCMConnected;

        public delegate void evConsoleHandler(object sender, String text);
        public event evConsoleHandler evConsoleOutput;


        private QCMUsbDevice _QCMUSBDevice;
        private EventWaitHandle _waitHandle = new EventWaitHandle(false, EventResetMode.AutoReset);
        static byte[] _ack_data = null;

        static bool device_connected = false;

        private bool _terminateThreads;
        private Thread _usbConnectionThread;
        private Thread _sendThread;
        private byte[] _keyFile;

        String _customerID;

        public QCMDevice()
        {
            _terminateThreads = false;


            _usbConnectionThread = new Thread(() =>
            {
                try
                {
                    USBConnectionThread();
                }
                catch (OperationCanceledException)
                {
                    
                }
            });

            _usbConnectionThread.Start();

        }

        ~QCMDevice()
        {
            Disconnect();
        }

        public void Disconnect()
        {
            if (_QCMUSBDevice != null)
            {
                _QCMUSBDevice.Disconnect();
            }

            _terminateThreads = true;

            if (false == _usbConnectionThread.Join(1000))
            {
                _usbConnectionThread.Abort();
            }

            device_connected = false;
        }

        private void USBConnectionThread()
        {
            while (!_terminateThreads)
            {
                if (!device_connected)
                {
                    try
                    {
                        _QCMUSBDevice = new QCMUsbDevice();
                        _QCMUSBDevice.evDataReceived += USBReadEventHandler;
                        _QCMUSBDevice.evDisconnected += USBDisconnectHandler;
                        
                        bool in_bootloader;
                        byte[] serial_num;
                        UInt32 boot_ver;
                        UInt32 script_ver;
                        byte[] mfg_info;
                        if (true == get_module_data(out in_bootloader, out serial_num, out boot_ver, out script_ver, out mfg_info, out _customerID))
                        {
                            evQCMConnected(this, in_bootloader, serial_num, boot_ver, script_ver, mfg_info, _customerID);
                            device_connected = true;
                        }
                        else
                        {
                            _QCMUSBDevice.Disconnect();
                        }
                    }
                    catch (QCMUsbDeviceException ex)
                    {
                        /* no connection */
                    }
                }

                Thread.Sleep(500);

            }
        }

        private void USBReadEventHandler(object sender, byte[] rx_data)
        {
            if (rx_data[0] == 0x01)
            {
                /* debug output */
                Console.WriteLine("Debug: " + System.Text.Encoding.ASCII.GetString(rx_data.RangeSubset(1, rx_data.Length - 1)));
                evDebugDataReceived(this, System.Text.Encoding.ASCII.GetString(rx_data.RangeSubset(1, rx_data.Length - 1)));
            }
            else if (rx_data[0] == 0x00)
            {
                /* ACK received */
                Console.WriteLine("Ack Received");
                _ack_data = rx_data.RangeSubset(2, rx_data.Length - 2);
                _waitHandle.Set();
            }

        }

        private void USBDisconnectHandler(object sender)
        {
            device_connected = false;
            evQCMDisconnected(this);
        }

        private bool send_script_update_start()
        {
            List<byte> frame = new List<byte>();
            bool ret_value = false;
            
            Console.WriteLine("U Start");
            _QCMUSBDevice.WriteMsg(0x13, frame.ToArray());

            if (false == _waitHandle.WaitOne(50000))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for start script update received");
            }
            else
            {
                return true;
            }


            return ret_value;
        }

        private bool send_script_update_frame(UInt16 frame_number, byte[] frame_data)
        {
            List<byte> frame = new List<byte>();
            bool ret_value = false;
            int retries = 0;

            frame.Add((byte)(frame_number >> 8));
            frame.Add((byte)(frame_number));
            frame.AddRange(frame_data);

            Console.WriteLine("U Frame");

            _QCMUSBDevice.WriteMsg(0x14, frame.ToArray());

            if (false == _waitHandle.WaitOne(2000))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for script update frame received");
            }
            else
            {
                return true;
            }

            return ret_value;

        }

        private bool send_script_update_end()
        {
            bool ret_value = false;
            int retries = 0;

            Console.WriteLine("U End");

           _QCMUSBDevice.WriteMsg(0x15, null);

            if (false == _waitHandle.WaitOne(500))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for end script update received");
            }
            else
            {
                return true;
            }

            return ret_value;

        }

        private bool send_update_start()
        {
            List<byte> frame = new List<byte>();
            bool ret_value = false;
            int retries = 0;
            
            _QCMUSBDevice.WriteMsg(0x20, frame.ToArray());

            if (false == _waitHandle.WaitOne(2000))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for start update received");
            }
            else
            {
                return true;
            }

            return ret_value;
        }

        private bool send_update_frame(UInt16 frame_number, byte[] frame_data)
        {
            List<byte> frame = new List<byte>();
            bool ret_value = false;

            frame.Add((byte)(frame_number >> 8));
            frame.Add((byte)(frame_number));
            frame.AddRange(frame_data);

            _QCMUSBDevice.WriteMsg(0x21, frame.ToArray());

            if (false == _waitHandle.WaitOne(20000))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for update frame received");
            }
            else
            {
                return true;
            }

            
            return ret_value;

        }

        private bool send_update_end()
        {
            bool ret_value = false;
            int retries = 0;

            _QCMUSBDevice.WriteMsg(0x22, null);

            if (false == _waitHandle.WaitOne(500))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for end update received");
            }
            else
            {
                return true;
            }

            return ret_value;

        }


        private bool get_module_data(out bool in_bootloader, out byte[] serial_num, out UInt32 app_ver, out UInt32 script_ver, out byte[] mfg_info, out String customer_id)
        {
            bool ret_value = false;
            int retries = 0;

            in_bootloader = false;
            app_ver = 0;
            script_ver = 0;
            mfg_info = null;
            serial_num = null;
            customer_id = null;

            Console.WriteLine("Mod Data");
            _QCMUSBDevice.WriteMsg(0xF0, null);

            if (false == _waitHandle.WaitOne(500))
            {
                /* no ack received */
                evConsoleOutput(this, "No Ack for get module info received");
            }
            else
            {
                serial_num = _ack_data.RangeSubset(0, 12);

                app_ver = (UInt32)_ack_data[12] << 24;
                app_ver += (UInt32)_ack_data[13] << 16;
                app_ver += (UInt32)_ack_data[14] << 8;
                app_ver += (UInt32)_ack_data[15];

                if (app_ver > 0x80000000)
                {
                    in_bootloader = true;
                }
                else
                {
                    in_bootloader = false;
                }

                script_ver = (UInt32)_ack_data[16] << 24;
                script_ver += (UInt32)_ack_data[17] << 16;
                script_ver += (UInt32)_ack_data[18] << 8;
                script_ver += (UInt32)_ack_data[19];

                mfg_info = _ack_data.RangeSubset(20, 16);
                customer_id = Encoding.ASCII.GetString(_ack_data.RangeSubset(36, 16), 0, 16).TrimEnd(new char[] { (char)0 });

                return true;
            }

            return ret_value;
        }

        
        public void SendScript(String filename)
        {
            _sendThread = new Thread(() =>
            {
                try
                {
                    SendScriptThread(filename);
                }
                catch (OperationCanceledException)
                {

                }
            });

            _sendThread.Start();
        }

        public bool SendScriptThread(String filename)
        {
            byte[] script;

            if (device_connected)
            {
                try
                {
                    script = File.ReadAllBytes(filename);
                }
                catch
                {
                    return false;
                }

                if (true == send_script_update_start())
                {
                    /* can now send the native update */
                    int offset = 0;
                    UInt16 frame_counter = 0;
                    int total_frames = (script.Length + 56) / 56;

                    while (offset < script.Length)
                    {
                        int data_size = (script.Length - offset);

                        if (data_size > 56)
                        {
                            data_size = 56;
                        }

                        evConsoleOutput(this, string.Format("Writing Frame {0} of {1}", frame_counter, total_frames));

                        if (true == send_script_update_frame(frame_counter, script.RangeSubset(offset, data_size)))
                        {
                            offset += data_size;
                            frame_counter++;
                        }
                        else
                        {
                            return false;
                        }
                    }

                    if (true == send_script_update_end())
                    {
                        evConsoleOutput(this, "Image Loaded\n");
                        return true;
                    }
                    else
                    {
                        evConsoleOutput(this, "Image not accepted by module\n");
                    }
                }
                else
                {
                    /* send garbage to the module */
                    evConsoleOutput(this, "Could not unlock module, module did not respond to unlock request\n");
                }
            }

            return false;

        }

        public void SendUpdate(String filename)
        {
            _sendThread = new Thread(() =>
            {
                try
                {
                    SendUpdateThread(filename);
                }
                catch (OperationCanceledException)
                {

                }
            });

            _sendThread.Start();
        }

        private bool SendUpdateThread(String filename)
        {
            byte[] update;

            if (device_connected)
            {
                try
                {
                    update = File.ReadAllBytes(filename);
                }
                catch
                {
                    return false;
                }

                if (true == send_update_start())
                {
                    /* can now send the native update */
                    int offset = 0;
                    UInt16 frame_counter = 0;
                    int total_frames = (update.Length + 56) / 56;

                    while (offset < update.Length)
                    {
                        int data_size = (update.Length - offset);

                        if (data_size > 56)
                        {
                            data_size = 56;
                        }

                        evConsoleOutput(this, string.Format("Writing Frame {0} of {1}", frame_counter, total_frames));

                        if (true == send_update_frame(frame_counter, update.RangeSubset(offset, data_size)))
                        {
                            offset += data_size;
                            frame_counter++;
                        }
                        else
                        {
                            return false;
                        }
                    }

                    if (true == send_update_end())
                    {
                        evConsoleOutput(this, "Image Loaded\n");
                        return true;
                    }
                    else
                    {
                        evConsoleOutput(this, "Image not accepted by module\n");
                    }
                }
            }
            return false;
        }

        public void SendDebug(byte[] data)
        {
            _QCMUSBDevice.WriteMsg(0x01, data);
        }
    }
}
