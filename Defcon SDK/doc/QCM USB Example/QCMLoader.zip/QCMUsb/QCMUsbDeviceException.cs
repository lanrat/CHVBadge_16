﻿/******************************************************************************
 * Copyright 2016 Specialized Solutions LLC
 *
 * Title to the Materials (contents of this file) remain with Specialized
 * Solutions LLC.  The Materials are copyrighted and are protected by United
 * States copyright laws.  Copyright notices cannot be removed from the
 * Materials.
 *
 * See the file titled "Specialized Solutions LLC License Agreement.txt"
 * that has been distributed with this file for further licensing details.
 *
 *****************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QCMUsb
{
    public class QCMUsbDeviceException:Exception
    {
        public QCMUsbDeviceException()
        {

        }

        public QCMUsbDeviceException(string message)
        : base(message)
        {

        }

        public QCMUsbDeviceException(string message, Exception inner)
        : base(message, inner)
        {

        }
    }
}
