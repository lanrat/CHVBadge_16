﻿/******************************************************************************
 * Copyright 2016 Specialized Solutions LLC
 *
 * Title to the Materials (contents of this file) remain with Specialized
 * Solutions LLC.  The Materials are copyrighted and are protected by United
 * States copyright laws.  Copyright notices cannot be removed from the
 * Materials.
 *
 * See the file titled "Specialized Solutions LLC License Agreement.txt"
 * that has been distributed with this file for further licensing details.
 *
 *****************************************************************************/
 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using MadWizard.WinUSBNet;

namespace QCMUsb
{
    public class QCMUsbDevice
    {

        private USBDevice device;
        private USBInterface iface;

        public delegate void evDataReceivedHandler(object sender, byte[] received_data);
        public event evDataReceivedHandler evDataReceived;

        public delegate void evDisconnectedHandler(object sender);
        public event evDisconnectedHandler evDisconnected;

        private bool _terminateThreads;
        private Thread _usbInputThread;

        private void USBReadThread()
        {
            byte[] in_data = new byte[64];
            
            int bytes_read;

            while (!_terminateThreads)
            {
                try
                {
                    bytes_read = iface.InPipe.Read(in_data);
                }
                catch
                {
                    _terminateThreads = true;
                    bytes_read = 0;
                    evDisconnected(this);
                }
                
                if (bytes_read > 0)
                {
                    //Console.WriteLine("USB Received");
                    if (bytes_read < 64)
                    {
                        evDataReceived(this, in_data.RangeSubset(0, bytes_read));
                    }
                    else
                    {
                        evDataReceived(this, in_data);
                    }
                }  
            }
        }

        public QCMUsbDevice()
        {
            try
            {
                device = USBDevice.GetSingleDevice("{EA0BD5C3-50F3-4888-84B4-74E50E1649DB}");
            }
            catch (USBException ex)
            {
                throw new QCMUsbDeviceException("Cannot find QCM Device");
            }

            if (device == null)
            {
                throw new QCMUsbDeviceException("Cannot find QCM Device");
            }
            
            //find the interfaces
            try
            {
                iface = device.Interfaces.Find(USBBaseClass.VendorSpecific);
            }
            catch (USBException ex)
            {
                throw new QCMUsbDeviceException("Cannot query device interfaces");
            }

            _terminateThreads = false;

            _usbInputThread = new Thread(() =>
            {
                try
                {
                    USBReadThread();
                }
                catch (OperationCanceledException)
                {
                    //Console.WriteLine("USB read/write thread closed");
                }
            });

            _usbInputThread.Start();

        }

        public void Disconnect()
        {
            _terminateThreads = true;

            try
            {
                iface.InPipe.Abort();
            }
            catch
            {

            }

            if (false == _usbInputThread.Join(1000))
            {
                _usbInputThread.Abort();
            }
        }

        public void Write(byte[] out_data)
        {
            iface.OutPipe.Write(out_data);
        }

        public void WriteMsg(byte command, byte[] out_data)
        {
            byte[] cmd_msg = new byte[1];

            cmd_msg[0] = command;
            byte[] send_msg = cmd_msg;

            if (out_data != null)
            {
                send_msg = cmd_msg.Append(out_data);
            }

            iface.OutPipe.Write(send_msg);

        }
    }
}
