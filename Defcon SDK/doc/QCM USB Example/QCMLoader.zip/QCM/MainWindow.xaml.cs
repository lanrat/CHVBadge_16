﻿/******************************************************************************
 * Copyright 2016 Specialized Solutions LLC
 *
 * Title to the Materials (contents of this file) remain with Specialized
 * Solutions LLC.  The Materials are copyrighted and are protected by United
 * States copyright laws.  Copyright notices cannot be removed from the
 * Materials.
 *
 * See the file titled "Specialized Solutions LLC License Agreement.txt"
 * that has been distributed with this file for further licensing details.
 *
 *****************************************************************************/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using QCMUsb;

namespace QCM
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private QCMDevice _QCMDevice;
        private bool _deviceConnected = false;
        private bool _in_bootloader = false;

        public MainWindow()
        {
            _QCMDevice = new QCMDevice();
            _QCMDevice.evDebugDataReceived += DebugDataReceivedHandler;
            _QCMDevice.evQCMDisconnected += DisconnectedHandler;
            _QCMDevice.evQCMConnected += ConnectedHandler;
            _QCMDevice.evConsoleOutput += ConsoleHandler;

            InitializeComponent();
        }

        private void DebugDataReceivedHandler(object sender, string rx_data)
        {
            Action action = () => tbHostReceive.AppendText(rx_data);
            Dispatcher.Invoke(action);
        }

        private void ConsoleHandler(object sender, string text)
        {
            Action action = () => tbHostReceive.AppendText(text + "\n");
            Dispatcher.Invoke(action);
        }

        private void DisconnectedHandler(object sender)
        {
            _deviceConnected = false;
            _in_bootloader = false;
            Action action = () => lbStatus.Content = "No Device Connected";
            Dispatcher.Invoke(action);
        }

        private void ConnectedHandler(object sender, bool in_bootloader, byte[] serial_num, UInt32 app_version, UInt32 script_ver, byte[] mfg_info, String customer_id)
        {
            _deviceConnected = true;
            Action action = () => lbStatus.Content = "Device Connected";
            Dispatcher.Invoke(action);

            String moduleInfo = "";

            if (in_bootloader)
            {
                moduleInfo += "In Bootloader\n";
                _in_bootloader = true;
            }
            else
            {
                moduleInfo += "Not In Bootloader\n";
                _in_bootloader = false;
            }

            action = () => tbHostReceive.AppendText(moduleInfo);
            Dispatcher.Invoke(action);

            moduleInfo = "";

            moduleInfo += "Serial Number: " + ByteArrayToString(serial_num) + "\n";

            action = () => tbHostReceive.AppendText(moduleInfo);
            Dispatcher.Invoke(action);

            moduleInfo = "";

            moduleInfo += String.Format("Application Version: {0:X8}\nScript Version: {1:X8}\n", app_version, script_ver);

            action = () => tbHostReceive.AppendText(moduleInfo);
            Dispatcher.Invoke(action);

            moduleInfo = "";

            moduleInfo += "Mfg Info: " + ByteArrayToString(mfg_info) + "\n";

            action = () => tbHostReceive.AppendText(moduleInfo);
            Dispatcher.Invoke(action);

            moduleInfo = "";

            moduleInfo += "Customer: " + customer_id;

            action = () => tbHostReceive.AppendText(moduleInfo);
            Dispatcher.Invoke(action);

        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            _QCMDevice.Disconnect();
        }

        private void bLoadScript_Click(object sender, RoutedEventArgs e)
        {
            if (!_deviceConnected)
            {
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "AMX Files|*.amx";
            if (openFileDialog.ShowDialog() == true)
            {
                /* send the script to the unit */
                _QCMDevice.SendScript(openFileDialog.FileName);
                
            }
        }

        private void bLoadFirmware_Click(object sender, RoutedEventArgs e)
        {
            if ((!_deviceConnected) || (!_in_bootloader))
            {
                return;
            }

            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "QUP Files|*.qup";
            if (openFileDialog.ShowDialog() == true)
            {
                /* send the update to the unit */
                _QCMDevice.SendUpdate(openFileDialog.FileName);
            }
        }

        private void tbHostReceive_TextChanged(object sender, TextChangedEventArgs e)
        {
            tbHostReceive.ScrollToEnd();
        }

        private void bClearHost_Click(object sender, RoutedEventArgs e)
        {
            tbHostReceive.Clear();
        }

        private void bCopyHost_Click(object sender, RoutedEventArgs e)
        {
            tbHostReceive.SelectAll();
            tbHostReceive.Copy();
            tbHostReceive.Select(0, 0);
        }

        private void tbHostSend_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                e.Handled = true;
                if (_deviceConnected)
                {
                    tbHostReceive.AppendText("--> " + tbHostSend.Text + "\n");
                    byte[] write_data = Encoding.ASCII.GetBytes(tbHostSend.Text);
                    _QCMDevice.SendDebug(write_data);
                    tbHostSend.Text = "";
                }
            }
        }

        private string ByteArrayToString(byte[] ba)
        {
            StringBuilder hex = new StringBuilder(ba.Length * 2);
            foreach (byte b in ba)
                hex.AppendFormat("{0:x2}", b);
            return hex.ToString();
        }


    }
}
